# Local Message Simulator

A mobile-first, offline-capable messaging simulation built with React, TypeScript, Vite, and IndexedDB. It does not connect to a messaging service. Messages are saved on the device and are never delivered.

The source and production build contain no names, phone numbers, or conversation text. The private starter data is supplied separately as **Aashna-Mam-local-starter.json**; do not copy that file into this project, its public directory, or a GitHub repository.

## Project structure

~~~text
local-messaging-simulator/
├── .github/workflows/deploy.yml   # Free GitHub Pages deployment
├── public/                        # App icons, manifest, service-worker fallback
├── src/
│   ├── domain/                    # IndexedDB and backup validation
│   ├── App.tsx                    # Screens and interactions
│   ├── main.tsx                   # React and service worker entry
│   └── styles.css                 # Responsive iOS-inspired interface
├── index.html
├── package.json
├── package-lock.json
├── scripts/generate-service-worker.mjs
└── vite.config.ts                 # Relative paths for static hosting
~~~

## Run on Windows

Install the current Node.js LTS release from [nodejs.org](https://nodejs.org/). In PowerShell, open this folder and run:

~~~powershell
npm ci
npm run dev
~~~

Open the local URL printed in the terminal, usually **http://localhost:5173**.

Create the production files with:

~~~powershell
npm run build
~~~

The complete static site and generated offline service worker are written to **dist/**. **npm run preview** opens that built site locally.

## Set up the private starter data

The static app intentionally ships without contact records. This keeps personal contact details and message text out of the hosted files.

1. Keep **Aashna-Mam-local-starter.json** separate from this project folder.
2. Open the app in Safari or another browser on the device where you want to use it.
3. Choose **Import private starter file** on the home screen, or open **Local data → Import or restore backup**.
4. Select the JSON file. The first import saves its records directly into that device’s IndexedDB.

The starter data contains a local contact record and two historical simulation entries visible in the supplied reference. The complete entries are dated 8 October 2026 at 8:27 PM and 9 October 2026 at 8:19 PM (India local time). The screenshot clips the 10 October entry before its time and full text are visible, so that incomplete entry is not seeded. Further messages can be composed in the app. The starter file is not copied into **dist/** by Vite.

### Move the starter file from Windows to iPhone without a cloud service

The JSON is a local file. One free option is to transfer it over your own Wi-Fi:

1. Put the JSON in a private folder on the Windows laptop.
2. In PowerShell, change to that folder and run **python -m http.server 8000 --bind 0.0.0.0**.
3. Find the laptop’s IPv4 address with **ipconfig**.
4. While both devices are on the same Wi-Fi, open **http://LAPTOP-IP:8000/Aashna-Mam-local-starter.json** in iPhone Safari and save the file to **Files**.
5. Stop the laptop server with **Ctrl+C**. Then open the HTTPS app on iPhone and import the file from **Files**.

This temporary file transfer stays on the local Wi-Fi network. Do not configure router port forwarding or expose the temporary server to the internet. The app’s message database remains on the iPhone after import.

## Use the app

- On **Chats**, the first contact is kept in a separate row above the other six. Only that row and its conversation navigation open.
- In the conversation, type text or emoji and tap the green send control. Each message is saved to IndexedDB with its creation timestamp, displays two grey decorative checks, and is labelled **Saved locally • Not delivered**.
- Tap the contact avatar or name, or the information button, to open contact information. **Edit contact** saves the name and number locally. The app has no call or external messaging action.
- Use the attachment button to add a historical simulation. Choose a date and time; the record is visibly marked as simulated history.
- Tap the message’s options control and confirm to delete an individual message.
- **Local data → Export local backup** downloads a JSON file. **Import or restore backup** validates a file and, after confirmation, replaces the records on that device.
- **Clear this device’s app data** asks for confirmation and then clears IndexedDB.

Backups contain the contact details and message text. Keep them private. Importing a backup on another device is a manual copy and does not sync devices.

## Free HTTPS deployment with GitHub Pages

The included workflow builds and publishes only the generic app shell. Its static assets do not contain the separate private starter file or any local IndexedDB records.

1. Create a free GitHub account if needed, then create a repository for the app.
2. Upload the contents of this **local-messaging-simulator** folder to the repository. Do not upload the sibling starter JSON file.
3. In the repository, open **Settings → Pages** and choose **GitHub Actions** as the publishing source.
4. The included workflow runs when you push to the **main** branch. Wait for the **Build and publish** workflow to complete.
5. Find the HTTPS site address under **Settings → Pages** or the workflow deployment summary.
6. Open the HTTPS address in iPhone Safari and add it to the Home Screen.

No backend, custom domain, payment, or cloud database is needed. GitHub Free Pages requires a public repository, so only upload the generic app source/build; do not upload the separate starter JSON. GitHub notes that Pages records visitor IP addresses for security. The app sends no message content or contact data to the host; each iPhone imports and stores its own local records.

## Install on iPhone

1. Open the deployed **HTTPS** URL in Safari.
2. Tap **Share**, then **Add to Home Screen**.
3. Keep **Open as Web App** enabled if shown, then tap **Add**.
4. Launch the new Home Screen icon once while online so the app shell and service worker finish caching.
5. Import the private starter JSON into the installed app.
6. To check offline shell support, close the app, enable Airplane Mode, and reopen it. The interface should load; network-hosted app updates will wait until the device is online again.

The app requests no camera or microphone permission. The camera control is a labelled simulation only.

## Local network preview and HTTPS limits

To preview from an iPhone while both devices share Wi-Fi:

1. Run **npm ci** once on Windows.
2. Start the Vite server with **npm run dev**.
3. Run **ipconfig** and note the laptop’s IPv4 address.
4. Open **http://LAPTOP-IP:5173** in iPhone Safari.

This is useful for layout checks, but a plain local IP address over HTTP is not a secure origin for service-worker installation. Use the free HTTPS deployment for Add to Home Screen installation and offline-shell verification.

## Privacy and local-only behavior

- React assets, icons, and the generated service worker are static files with no analytics or trackers.
- Contacts and messages use IndexedDB in the current browser profile on the current device.
- Outgoing messages are not delivered. The two grey checkmarks are decoration only.
- No SMS, telephone, messaging API, remote database, or synchronization code is included.
- Moving to a new browser or device requires exporting and manually importing a backup.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  Camera,
  CheckCheck,
  ChevronRight,
  Copy,
  Download,
  FileClock,
  Info,
  MessageCircle,
  MoreHorizontal,
  Paperclip,
  Plus,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  Smile,
  Trash2,
  Upload,
  UserRound,
  X
} from 'lucide-react';
import {
  clearLocalData,
  readAllData,
  removeMessage,
  replaceLocalData,
  saveContact,
  saveMessage
} from './domain/db';
import { makeBackup, validateBackup } from './domain/backup';
import {
  PRIMARY_CONTACT_ID,
  type Contact,
  type Message
} from './domain/types';

type Screen = 'home' | 'conversation' | 'contact' | 'settings';
type Popup = 'attachments' | 'camera' | null;

const EMOJI_CHOICES = ['🙂', '😊', '🙏', '❤️', '✨', '👍', '🎉', '🌿', '🥹', '💛', '👏', '☀️'];

function sortMessages(items: Message[]): Message[] {
  return [...items].sort((left, right) => Date.parse(left.createdAt) - Date.parse(right.createdAt));
}

function makeId(): string {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : 'message-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
}

function localDayKey(value: string): string {
  const date = new Date(value);
  return [date.getFullYear(), date.getMonth(), date.getDate()].join('-');
}

function dateHeading(value: string): string {
  const date = new Date(value);
  const now = new Date();
  const yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  const todayKey = [now.getFullYear(), now.getMonth(), now.getDate()].join('-');
  const yesterdayKey = [yesterday.getFullYear(), yesterday.getMonth(), yesterday.getDate()].join('-');
  if (localDayKey(value) === todayKey) return 'Today';
  if (localDayKey(value) === yesterdayKey) return 'Yesterday';
  return date.toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    ...(date.getFullYear() === now.getFullYear() ? {} : { year: 'numeric' })
  });
}

function formatTime(value: string): string {
  return new Date(value).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

function toLocalInputValue(date: Date): string {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60_000);
  return local.toISOString().slice(0, 16);
}

function formatPhone(countryCode: string, phoneNumber: string): string {
  const digits = phoneNumber.replace(/\D/g, '');
  const grouped = digits.length === 10 ? digits.slice(0, 5) + ' ' + digits.slice(5) : digits;
  return countryCode.trim() + (grouped ? ' ' + grouped : '');
}

function useVisibleViewportHeight(): void {
  useEffect(() => {
    const updateHeight = () => {
      const height = window.visualViewport?.height ?? window.innerHeight;
      document.documentElement.style.setProperty('--app-height', height + 'px');
    };
    updateHeight();
    window.addEventListener('resize', updateHeight);
    window.visualViewport?.addEventListener('resize', updateHeight);
    window.visualViewport?.addEventListener('scroll', updateHeight);
    return () => {
      window.removeEventListener('resize', updateHeight);
      window.visualViewport?.removeEventListener('resize', updateHeight);
      window.visualViewport?.removeEventListener('scroll', updateHeight);
    };
  }, []);
}

function Avatar({ contact, primary = false }: { contact: Contact; primary?: boolean }) {
  if (primary) {
    return (
      <span className="avatar avatar-primary" aria-hidden="true">
        <UserRound size={25} strokeWidth={1.65} />
      </span>
    );
  }
  const initials = contact.name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0] ?? '')
    .join('')
    .toUpperCase();
  return (
    <span
      className="avatar avatar-initials"
      style={{ '--avatar-tone': String((contact.order * 61 + 138) % 360) } as React.CSSProperties}
      aria-hidden="true"
    >
      {initials}
    </span>
  );
}

function IdentityBar() {
  return (
    <div className="identity-bar" role="note" aria-label="Demo local simulation, not WhatsApp">
      <span className="identity-dot" aria-hidden="true" />
      <span>DEMO • LOCAL SIMULATION • NOT WHATSAPP</span>
    </div>
  );
}

function IconButton({
  label,
  children,
  onClick,
  className = ''
}: {
  label: string;
  children: React.ReactNode;
  onClick: () => void;
  className?: string;
}) {
  return (
    <button className={'icon-button ' + className} type="button" aria-label={label} onClick={onClick}>
      {children}
    </button>
  );
}

function BottomNavigation({
  current,
  onHome,
  onConversation,
  onSettings,
  hasPrimary
}: {
  current: 'home' | 'conversation' | 'settings';
  onHome: () => void;
  onConversation: () => void;
  onSettings: () => void;
  hasPrimary: boolean;
}) {
  return (
    <nav className="bottom-nav" aria-label="Main navigation">
      <button
        type="button"
        className={'nav-item ' + (current === 'home' ? 'active' : '')}
        aria-current={current === 'home' ? 'page' : undefined}
        onClick={onHome}
      >
        <MessageCircle size={20} strokeWidth={2} />
        <span>Chats</span>
      </button>
      <button
        type="button"
        className={'nav-item ' + (current === 'conversation' ? 'active' : '')}
        aria-current={current === 'conversation' ? 'page' : undefined}
        onClick={onConversation}
        disabled={!hasPrimary}
      >
        <UserRound size={20} strokeWidth={2} />
        <span>Conversation</span>
      </button>
      <button
        type="button"
        className={'nav-item ' + (current === 'settings' ? 'active' : '')}
        aria-current={current === 'settings' ? 'page' : undefined}
        onClick={onSettings}
      >
        <Settings2 size={20} strokeWidth={2} />
        <span>Local data</span>
      </button>
    </nav>
  );
}

function HomeScreen({
  contacts,
  messages,
  search,
  setSearch,
  onHome,
  onOpenPrimary,
  onSettings,
  onAddHistorical,
  onImport
}: {
  contacts: Contact[];
  messages: Message[];
  search: string;
  setSearch: (value: string) => void;
  onHome: () => void;
  onOpenPrimary: () => void;
  onSettings: () => void;
  onAddHistorical: () => void;
  onImport: () => void;
}) {
  const primary = contacts.find((contact) => contact.id === PRIMARY_CONTACT_ID);
  const others = contacts
    .filter((contact) => contact.id !== PRIMARY_CONTACT_ID)
    .filter((contact) => contact.name.toLowerCase().includes(search.trim().toLowerCase()));
  const latestMessage = messages.length ? messages[messages.length - 1] : undefined;

  return (
    <section className="screen home-screen" aria-label="Chats">
      <header className="home-header">
        <div className="home-actions">
          <IconButton label="Open local data settings" onClick={onSettings}>
            <MoreHorizontal size={23} />
          </IconButton>
          <div className="home-action-right">
            <span className="device-pill"><ShieldCheck size={15} /> This device</span>
            <IconButton
              label={primary ? 'Add a historical demo message' : 'Import private starter file'}
              className="add-button"
              onClick={primary ? onAddHistorical : onImport}
            >
              <Plus size={24} />
            </IconButton>
          </div>
        </div>
        <h1>Chats</h1>
        <label className="search-field">
          <Search size={19} aria-hidden="true" />
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            type="search"
            placeholder="Search local contacts"
            aria-label="Search local contacts"
          />
          {search && (
            <button type="button" aria-label="Clear search" onClick={() => setSearch('')}>
              <X size={16} />
            </button>
          )}
        </label>
      </header>

      <div className="contact-list-area">
        {primary ? (
          <button className="contact-row primary-row" type="button" onClick={onOpenPrimary}>
            <Avatar contact={primary} primary />
            <span className="contact-copy">
              <span className="contact-name">{primary.name}</span>
              <span className="contact-preview">
                {latestMessage?.text ?? primary.localPreview ?? 'Open your local conversation'}
              </span>
            </span>
            <span className="contact-trailing">
              <span className="contact-time">
                {latestMessage ? formatTime(latestMessage.createdAt) : primary.displayTime ?? ''}
              </span>
              <ChevronRight size={16} aria-hidden="true" />
            </span>
          </button>
        ) : (
          <div className="setup-card">
            <span className="setup-icon"><ShieldCheck size={20} /></span>
            <div className="setup-copy">
              <strong>Set up your private demo</strong>
              <p>Import the starter file on this device. Its contact details and message history are not part of the hosted app.</p>
              <button type="button" className="text-action" onClick={onImport}>
                Import private starter file <ChevronRight size={15} />
              </button>
            </div>
          </div>
        )}

        <div className="list-label">
          <span>CONTACTS</span>
          <span>{others.length} shown</span>
        </div>
        <div className="contact-list" aria-label="Other local contacts">
          {others.map((contact) => (
            <div
              className="contact-row static-row"
              aria-label={contact.name + ', non-interactive demo contact'}
              key={contact.id}
            >
              <Avatar contact={contact} />
              <span className="contact-copy">
                <span className="contact-name">{contact.name}</span>
                <span className="contact-preview">{contact.localPreview ?? 'Fictional local preview'}</span>
              </span>
              <span className="contact-trailing">
                <span className="contact-time">{contact.displayTime ?? ''}</span>
              </span>
            </div>
          ))}
          {contacts.length > 0 && others.length === 0 && (
            <p className="empty-filter">No other contacts match this search.</p>
          )}
        </div>
        <p className="list-footnote">Only the first contact opens. Other rows are visual demo examples.</p>
      </div>

      <BottomNavigation
        current="home"
        onHome={onHome}
        onConversation={onOpenPrimary}
        onSettings={onSettings}
        hasPrimary={Boolean(primary)}
      />
    </section>
  );
}

function groupMessages(messages: Message[]): { key: string; entries: Message[] }[] {
  const groups: { key: string; entries: Message[] }[] = [];
  for (const message of messages) {
    const key = localDayKey(message.createdAt);
    const current = groups[groups.length - 1];
    if (!current || current.key !== key) groups.push({ key, entries: [message] });
    else current.entries.push(message);
  }
  return groups;
}

function ConversationScreen({
  contact,
  messages,
  onBack,
  onInfo,
  onDelete,
  onSend,
  onHistorical,
  onToast
}: {
  contact: Contact;
  messages: Message[];
  onBack: () => void;
  onInfo: () => void;
  onDelete: (message: Message) => void;
  onSend: (text: string) => Promise<void>;
  onHistorical: () => void;
  onToast: (value: string) => void;
}) {
  const [draft, setDraft] = useState('');
  const [popup, setPopup] = useState<Popup>(null);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const groups = useMemo(() => groupMessages(messages), [messages]);

  useEffect(() => {
    const element = scrollRef.current;
    if (!element) return;
    element.scrollTo({ top: element.scrollHeight, behavior: 'smooth' });
  }, [messages.length]);

  useEffect(() => {
    const element = textareaRef.current;
    if (!element) return;
    element.style.height = 'auto';
    element.style.height = Math.min(element.scrollHeight, 132) + 'px';
  }, [draft]);

  const send = async () => {
    const value = draft.trim();
    if (!value || sending) return;
    setSending(true);
    try {
      await onSend(value);
      setDraft('');
      setEmojiOpen(false);
      textareaRef.current?.focus();
    } catch {
      // The app-level save flow already reports local storage errors.
    } finally {
      setSending(false);
    }
  };

  const insertEmoji = (emoji: string) => {
    setDraft((value) => value + emoji);
    setEmojiOpen(false);
    textareaRef.current?.focus();
  };

  return (
    <section className="screen conversation-screen" aria-label="Conversation">
      <header className="conversation-header">
        <IconButton label="Back to chats" onClick={onBack} className="back-button">
          <ArrowLeft size={21} />
        </IconButton>
        <button type="button" className="conversation-person" onClick={onInfo} aria-label="Open contact information">
          <Avatar contact={contact} primary />
          <span className="conversation-person-copy">
            <strong>{contact.name}</strong>
            <small>Local conversation</small>
          </span>
        </button>
        <div className="conversation-actions">
          <IconButton label="Contact information" onClick={onInfo}>
            <Info size={20} />
          </IconButton>
          <div className="more-anchor">
            <IconButton label="More conversation options" onClick={() => setMoreOpen((value) => !value)}>
              <MoreHorizontal size={21} />
            </IconButton>
            {moreOpen && (
              <div className="more-menu">
                <button type="button" onClick={() => { setMoreOpen(false); onInfo(); }}>
                  <Info size={16} /> Contact information
                </button>
                <button type="button" onClick={() => { setMoreOpen(false); onHistorical(); }}>
                  <FileClock size={16} /> Add historical demo
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <div className="conversation-wallpaper" ref={scrollRef} aria-live="polite">
        {messages.length === 0 ? (
          <div className="conversation-empty">
            <span className="empty-emblem"><MessageCircle size={21} /></span>
            <strong>No local messages yet</strong>
            <p>Your messages stay on this device and are never delivered.</p>
          </div>
        ) : (
          <div className="message-stack">
            {groups.map((group) => {
              const historicalGroup = group.entries.some((message) => message.historical);
              return (
                <div className="message-group" key={group.key}>
                  <div className="date-divider">
                    <span>{dateHeading(group.entries[0].createdAt)}</span>
                    {historicalGroup && <small>SIMULATED HISTORY</small>}
                  </div>
                  {group.entries.map((message) => (
                    <article className="message-line outgoing-line" key={message.id}>
                      <div className="message-bubble">
                        <p>{message.text}</p>
                        <div className="message-meta">
                          {message.historical && <span className="historical-mark">SIMULATION</span>}
                          <time dateTime={message.createdAt}>{formatTime(message.createdAt)}</time>
                          <CheckCheck className="double-check" size={16} strokeWidth={2.25} aria-label="Two grey simulation checkmarks" />
                          <button
                            type="button"
                            className="delete-message"
                            aria-label="Delete this message"
                            title="Delete message"
                            onClick={() => onDelete(message)}
                          >
                            <MoreHorizontal size={16} />
                          </button>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {messages.length > 3 && (
        <button
          type="button"
          className="scroll-latest"
          aria-label="Scroll to latest message"
          onClick={() => scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })}
        >
          <ArrowDown size={18} />
        </button>
      )}

      {emojiOpen && (
        <div className="emoji-tray" role="group" aria-label="Choose an emoji">
          {EMOJI_CHOICES.map((emoji) => (
            <button type="button" key={emoji} onClick={() => insertEmoji(emoji)} aria-label={'Insert ' + emoji}>
              {emoji}
            </button>
          ))}
        </div>
      )}

      <footer className="composer-area">
        <div className="saved-status"><ShieldCheck size={13} /> Saved locally <span>•</span> Not delivered</div>
        <div className="composer-row">
          <IconButton label="Open local attachment options" className="composer-tool" onClick={() => setPopup('attachments')}>
            <Paperclip size={20} />
          </IconButton>
          <div className="input-shell">
            <textarea
              ref={textareaRef}
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="Message"
              aria-label="Message text"
              rows={1}
              enterKeyHint="enter"
            />
            <button
              type="button"
              className={'emoji-trigger ' + (emojiOpen ? 'selected' : '')}
              aria-label="Open emoji picker"
              onClick={() => setEmojiOpen((value) => !value)}
            >
              <Smile size={20} />
            </button>
          </div>
          <IconButton label="Camera simulation" className="composer-tool camera-tool" onClick={() => setPopup('camera')}>
            <Camera size={20} />
          </IconButton>
          <button
            type="button"
            className="send-button"
            aria-label="Save message locally"
            disabled={!draft.trim() || sending}
            onClick={() => void send()}
          >
            <Send size={18} />
          </button>
        </div>
        <span className="composer-hint">Text and emoji stay on this device.</span>
      </footer>

      {popup && (
        <Dialog
          title={popup === 'attachments' ? 'Local tools' : 'Camera simulation'}
          onClose={() => setPopup(null)}
          compact
        >
          {popup === 'attachments' ? (
            <div className="tool-list">
              <button type="button" onClick={() => { setPopup(null); onHistorical(); }}>
                <span className="tool-icon"><FileClock size={18} /></span>
                <span><strong>Add historical demo message</strong><small>Choose a date and time on this device</small></span>
                <ChevronRight size={17} />
              </button>
              <button type="button" onClick={() => setPopup('camera')}>
                <span className="tool-icon"><Camera size={18} /></span>
                <span><strong>Camera simulation</strong><small>No camera is opened or accessed</small></span>
                <ChevronRight size={17} />
              </button>
            </div>
          ) : (
            <div className="camera-message">
              <span className="camera-large"><Camera size={25} /></span>
              <p>This is a local-only camera placeholder. No camera is opened, and no media is captured or shared.</p>
              <button type="button" className="primary-action" onClick={() => { setPopup(null); onToast('Camera simulation only — nothing was captured.'); }}>
                Understood
              </button>
            </div>
          )}
        </Dialog>
      )}
    </section>
  );
}

function ContactScreen({
  contact,
  onBack,
  onSave,
  onToast
}: {
  contact: Contact;
  onBack: () => void;
  onSave: (contact: Contact) => Promise<void>;
  onToast: (value: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(contact.name);
  const [countryCode, setCountryCode] = useState(contact.countryCode);
  const [phoneNumber, setPhoneNumber] = useState(contact.phoneNumber);
  const [saving, setSaving] = useState(false);

  const copyNumber = async () => {
    const value = formatPhone(contact.countryCode, contact.phoneNumber);
    try {
      await navigator.clipboard.writeText(value);
      onToast('Number copied on this device.');
    } catch {
      const field = document.createElement('textarea');
      field.value = value;
      field.style.position = 'fixed';
      field.style.opacity = '0';
      document.body.append(field);
      field.select();
      const copied = document.execCommand('copy');
      field.remove();
      onToast(copied ? 'Number copied on this device.' : 'Copy is unavailable in this browser.');
    }
  };

  const save = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const cleanCode = countryCode.trim();
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    if (!name.trim() || !cleanCode || !cleanNumber) {
      onToast('Enter a contact name, country code, and phone number.');
      return;
    }
    setSaving(true);
    try {
      await onSave({
        ...contact,
        name: name.trim(),
        countryCode: cleanCode.startsWith('+') ? cleanCode : '+' + cleanCode,
        phoneNumber: cleanNumber,
        lastModifiedAt: new Date().toISOString()
      });
      setEditing(false);
      onToast('Contact details saved locally.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="screen detail-screen" aria-label="Contact information">
      <header className="subpage-header">
        <IconButton label="Back to conversation" onClick={onBack} className="back-button">
          <ArrowLeft size={21} />
        </IconButton>
        <h1>Contact information</h1>
        <span className="header-spacer" />
      </header>
      <div className="detail-scroll">
        <div className="profile-card">
          <Avatar contact={contact} primary />
          {!editing ? (
            <>
              <h2>{contact.name}</h2>
              <p className="profile-phone">{formatPhone(contact.countryCode, contact.phoneNumber)}</p>
              <div className="profile-actions">
                <button type="button" onClick={() => void copyNumber()}>
                  <Copy size={18} /><span>Copy number</span>
                </button>
                <button type="button" onClick={() => setEditing(true)}>
                  <Settings2 size={18} /><span>Edit contact</span>
                </button>
              </div>
            </>
          ) : (
            <form className="edit-contact-form" onSubmit={(event) => void save(event)}>
              <label>
                <span>Contact name</span>
                <input value={name} onChange={(event) => setName(event.target.value)} autoComplete="off" />
              </label>
              <div className="phone-edit-grid">
                <label>
                  <span>Country code</span>
                  <input value={countryCode} onChange={(event) => setCountryCode(event.target.value)} inputMode="tel" />
                </label>
                <label>
                  <span>Phone number</span>
                  <input value={phoneNumber} onChange={(event) => setPhoneNumber(event.target.value)} inputMode="tel" />
                </label>
              </div>
              <div className="form-actions">
                <button type="button" className="secondary-action" onClick={() => setEditing(false)}>Cancel</button>
                <button type="submit" className="primary-action" disabled={saving}>{saving ? 'Saving…' : 'Save locally'}</button>
              </div>
            </form>
          )}
        </div>

        {!editing && (
          <>
            <div className="info-card">
              <span className="info-icon"><ShieldCheck size={17} /></span>
              <div>
                <strong>Local simulation</strong>
                <p>This contact is a saved demo record. No call, SMS, or external conversation can be started here.</p>
              </div>
            </div>
            <div className="detail-note">
              <span>STORED ON THIS DEVICE</span>
              <p>Contact details are saved in this browser’s IndexedDB and included only if you export a backup.</p>
            </div>
          </>
        )}
      </div>
    </section>
  );
}

function SettingsScreen({
  hasData,
  onBack,
  onExport,
  onImport,
  onReset
}: {
  hasData: boolean;
  onBack: () => void;
  onExport: () => void;
  onImport: () => void;
  onReset: () => void;
}) {
  return (
    <section className="screen detail-screen" aria-label="Local data settings">
      <header className="subpage-header">
        <IconButton label="Back" onClick={onBack} className="back-button">
          <ArrowLeft size={21} />
        </IconButton>
        <h1>Local data</h1>
        <span className="header-spacer" />
      </header>
      <div className="settings-scroll">
        <div className="settings-intro">
          <span className="settings-emblem"><ShieldCheck size={22} /></span>
          <div>
            <h2>Your device, your records</h2>
            <p>Messages and contact details stay in this browser’s IndexedDB. There is no account or sync.</p>
          </div>
        </div>
        <section className="settings-section">
          <h3>BACKUP & RESTORE</h3>
          <button className="settings-row" type="button" onClick={onExport} disabled={!hasData}>
            <span className="settings-row-icon"><Download size={18} /></span>
            <span><strong>Export local backup</strong><small>Save a JSON copy to your device</small></span>
            <ChevronRight size={17} />
          </button>
          <button className="settings-row" type="button" onClick={onImport}>
            <span className="settings-row-icon"><Upload size={18} /></span>
            <span><strong>Import or restore backup</strong><small>Replaces the local records on this device</small></span>
            <ChevronRight size={17} />
          </button>
          <p className="section-caption">Backups include names, numbers, and message text. Keep the exported file private.</p>
        </section>
        <section className="settings-section">
          <h3>ABOUT THIS APP</h3>
          <div className="settings-note">
            <strong>Offline ready</strong>
            <p>The app shell is cached after the first successful load. Your records are separate from the hosted files.</p>
          </div>
          <div className="settings-note">
            <strong>Decorative status only</strong>
            <p>Two grey checks are visual simulation marks. Messages are not delivered, read, or sent anywhere.</p>
          </div>
        </section>
        <section className="settings-section reset-section">
          <h3>RESET</h3>
          <button className="settings-row reset-row" type="button" onClick={onReset} disabled={!hasData}>
            <span className="settings-row-icon"><Trash2 size={18} /></span>
            <span><strong>Clear this device’s app data</strong><small>Removes local contacts and conversation history</small></span>
            <ChevronRight size={17} />
          </button>
        </section>
      </div>
    </section>
  );
}

function Dialog({
  title,
  children,
  onClose,
  compact = false
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  compact?: boolean;
}) {
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  return (
    <div className="dialog-scrim" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className={'dialog-panel ' + (compact ? 'compact-dialog' : '')} role="dialog" aria-modal="true" aria-label={title}>
        <div className="dialog-heading">
          <h2>{title}</h2>
          <IconButton label="Close dialog" onClick={onClose} className="dialog-close"><X size={18} /></IconButton>
        </div>
        {children}
      </section>
    </div>
  );
}

function App() {
  useVisibleViewportHeight();
  const [screen, setScreen] = useState<Screen>('home');
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [ready, setReady] = useState(false);
  const [storageError, setStorageError] = useState('');
  const [search, setSearch] = useState('');
  const [toast, setToast] = useState('');
  const [historicalOpen, setHistoricalOpen] = useState(false);
  const [historicalText, setHistoricalText] = useState('');
  const [historicalDate, setHistoricalDate] = useState(() => toLocalInputValue(new Date()));
  const [confirm, setConfirm] = useState<{
    title: string;
    message: string;
    confirmLabel: string;
    danger?: boolean;
    onConfirm: () => Promise<void>;
  } | null>(null);
  const importRef = useRef<HTMLInputElement>(null);
  const toastTimer = useRef<number | undefined>(undefined);

  const refreshData = useCallback(async () => {
    const result = await readAllData();
    setContacts(result.contacts);
    setMessages(sortMessages(result.messages));
  }, []);

  useEffect(() => {
    let cancelled = false;
    readAllData()
      .then((result) => {
        if (cancelled) return;
        setContacts(result.contacts);
        setMessages(sortMessages(result.messages));
      })
      .catch((error: unknown) => {
        if (!cancelled) setStorageError(error instanceof Error ? error.message : 'Local storage could not be opened.');
      })
      .finally(() => { if (!cancelled) setReady(true); });
    return () => { cancelled = true; };
  }, []);

  const showToast = useCallback((value: string) => {
    setToast(value);
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(''), 3_400);
  }, []);

  useEffect(() => () => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
  }, []);

  const primary = contacts.find((contact) => contact.id === PRIMARY_CONTACT_ID);
  const openConversation = () => {
    if (!primary) {
      showToast('Import the private starter file first.');
      return;
    }
    setScreen('conversation');
  };

  const addMessage = async (text: string, historical = false, createdAt = new Date().toISOString()) => {
    if (!primary) {
      showToast('Import the private starter file first.');
      return;
    }
    const message: Message = {
      id: makeId(),
      contactId: PRIMARY_CONTACT_ID,
      text,
      direction: 'outgoing',
      createdAt,
      localStatus: 'saved-locally-not-delivered',
      historical
    };
    setMessages((current) => sortMessages([...current, message]));
    try {
      await saveMessage(message);
      showToast('Saved locally. Not delivered.');
    } catch (error) {
      setMessages((current) => current.filter((item) => item.id !== message.id));
      showToast(error instanceof Error ? error.message : 'Could not save the message locally.');
      throw error;
    }
  };

  const startDelete = (message: Message) => {
    setConfirm({
      title: 'Delete this message?',
      message: 'This removes the message from this device. It cannot be restored unless you have a backup.',
      confirmLabel: 'Delete message',
      danger: true,
      onConfirm: async () => {
        await removeMessage(message.id);
        setMessages((current) => current.filter((item) => item.id !== message.id));
        showToast('Message deleted from this device.');
      }
    });
  };

  const exportData = () => {
    if (!contacts.length) return;
    const backup = makeBackup(contacts, messages);
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'local-message-simulator-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    link.click();
    URL.revokeObjectURL(url);
    showToast('Backup created on this device.');
  };

  const onChooseImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    try {
      const parsed: unknown = JSON.parse(await file.text());
      const backup = validateBackup(parsed);
      if (!contacts.length) {
        await replaceLocalData(backup);
        await refreshData();
        setScreen('home');
        showToast('Private data restored to this device.');
        return;
      }
      setConfirm({
        title: 'Replace local data?',
        message: 'This backup will replace all contacts and messages currently saved in this browser.',
        confirmLabel: 'Replace and restore',
        onConfirm: async () => {
          await replaceLocalData(backup);
          await refreshData();
          setScreen('home');
          showToast('Backup restored to this device.');
        }
      });
    } catch (error) {
      showToast(error instanceof Error ? error.message : 'That file could not be imported.');
    }
  };

  const resetData = () => {
    setConfirm({
      title: 'Clear this device’s app data?',
      message: 'This permanently removes the saved contact details and all local messages from this browser. Export a backup first if you may need them later.',
      confirmLabel: 'Clear local data',
      danger: true,
      onConfirm: async () => {
        await clearLocalData();
        setContacts([]);
        setMessages([]);
        setScreen('home');
        showToast('Local app data cleared.');
      }
    });
  };

  const saveContactChanges = async (contact: Contact) => {
    await saveContact(contact);
    setContacts((current) => current.map((item) => item.id === contact.id ? contact : item));
  };

  const saveHistorical = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const text = historicalText.trim();
    const date = new Date(historicalDate);
    if (!text || !historicalDate || !Number.isFinite(date.getTime())) {
      showToast('Enter a message and a valid date and time.');
      return;
    }
    if (date.getTime() > Date.now()) {
      showToast('Historical entries must use a past date and time.');
      return;
    }
    try {
      await addMessage(text, true, date.toISOString());
      setHistoricalText('');
      setHistoricalDate(toLocalInputValue(new Date()));
      setHistoricalOpen(false);
    } catch {
      // The save flow already shows the local storage error.
    }
  };

  const body = !ready ? (
    <div className="loading-view"><span className="loading-mark"><MessageCircle size={21} /></span><span>Opening local space…</span></div>
  ) : storageError ? (
    <div className="storage-error">
      <ShieldCheck size={23} />
      <h1>Local storage unavailable</h1>
      <p>{storageError} Try reopening this app in Safari or another modern browser.</p>
    </div>
  ) : screen === 'conversation' && primary ? (
    <ConversationScreen
      contact={primary}
      messages={messages}
      onBack={() => setScreen('home')}
      onInfo={() => setScreen('contact')}
      onDelete={startDelete}
      onSend={(text) => addMessage(text)}
      onHistorical={() => setHistoricalOpen(true)}
      onToast={showToast}
    />
  ) : screen === 'contact' && primary ? (
    <ContactScreen
      contact={primary}
      onBack={() => setScreen('conversation')}
      onSave={saveContactChanges}
      onToast={showToast}
    />
  ) : screen === 'settings' ? (
    <SettingsScreen
      hasData={contacts.length > 0}
      onBack={() => setScreen('home')}
      onExport={exportData}
      onImport={() => importRef.current?.click()}
      onReset={resetData}
    />
  ) : (
    <HomeScreen
      contacts={contacts}
      messages={messages}
      search={search}
      setSearch={setSearch}
      onHome={() => setScreen('home')}
      onOpenPrimary={openConversation}
      onSettings={() => setScreen('settings')}
      onAddHistorical={() => setHistoricalOpen(true)}
      onImport={() => importRef.current?.click()}
    />
  );

  return (
    <main className="app-root">
      <IdentityBar />
      {body}
      <input
        ref={importRef}
        type="file"
        accept=".json,application/json"
        className="visually-hidden"
        aria-label="Choose a local backup file"
        onChange={(event) => void onChooseImport(event)}
      />
      {toast && <div className="toast-message" role="status" aria-live="polite">{toast}</div>}
      {historicalOpen && (
        <Dialog title="Add historical demo message" onClose={() => setHistoricalOpen(false)}>
          <form className="history-form" onSubmit={(event) => void saveHistorical(event)}>
            <p>Choose the local date and time shown for this simulated outgoing record. The original timestamp is stored unchanged.</p>
            <label>
              <span>Message</span>
              <textarea value={historicalText} onChange={(event) => setHistoricalText(event.target.value)} rows={4} required />
            </label>
            <label>
              <span>Date and time on this device</span>
              <input
                type="datetime-local"
                value={historicalDate}
                onChange={(event) => setHistoricalDate(event.target.value)}
                max={toLocalInputValue(new Date())}
                required
              />
            </label>
            <div className="history-label"><FileClock size={14} /> Clearly marked as simulated history</div>
            <div className="form-actions">
              <button type="button" className="secondary-action" onClick={() => setHistoricalOpen(false)}>Cancel</button>
              <button type="submit" className="primary-action">Save historical entry</button>
            </div>
          </form>
        </Dialog>
      )}
      {confirm && (
        <Dialog title={confirm.title} onClose={() => setConfirm(null)} compact>
          <div className="confirm-copy"><p>{confirm.message}</p></div>
          <div className="form-actions">
            <button type="button" className="secondary-action" onClick={() => setConfirm(null)}>Cancel</button>
            <button
              type="button"
              className={confirm.danger ? 'danger-action' : 'primary-action'}
              onClick={() => {
                const action = confirm.onConfirm;
                setConfirm(null);
                void action().catch((error: unknown) => showToast(error instanceof Error ? error.message : 'The local action could not be completed.'));
              }}
            >
              {confirm.confirmLabel}
            </button>
          </div>
        </Dialog>
      )}
    </main>
  );
}

export default App;

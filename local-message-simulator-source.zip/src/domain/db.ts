import type { BackupFile, Contact, Message } from './types';

const DB_NAME = 'local-message-simulator';
const DB_VERSION = 1;
let databasePromise: Promise<IDBDatabase> | undefined;

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Local database request failed.'));
  });
}

function transactionDone(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error ?? new Error('Local database update was cancelled.'));
    transaction.onerror = () => reject(transaction.error ?? new Error('Local database update failed.'));
  });
}

export function openDatabase(): Promise<IDBDatabase> {
  if (!('indexedDB' in window)) {
    return Promise.reject(new Error('IndexedDB is unavailable in this browser.'));
  }
  if (!databasePromise) {
    databasePromise = new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('contacts')) {
          db.createObjectStore('contacts', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('messages')) {
          const messages = db.createObjectStore('messages', { keyPath: 'id' });
          messages.createIndex('contactId', 'contactId', { unique: false });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error('Could not open local storage.'));
      request.onblocked = () => reject(new Error('Close another copy of the app, then try again.'));
    }).catch((error) => {
      databasePromise = undefined;
      throw error;
    });
  }
  return databasePromise!;
}

export async function readAllData(): Promise<{ contacts: Contact[]; messages: Message[] }> {
  const db = await openDatabase();
  const transaction = db.transaction(['contacts', 'messages'], 'readonly');
  const done = transactionDone(transaction);
  const contactsRequest = requestResult<Contact[]>(transaction.objectStore('contacts').getAll());
  const messagesRequest = requestResult<Message[]>(transaction.objectStore('messages').getAll());
  const [contacts, messages] = await Promise.all([contactsRequest, messagesRequest]);
  await done;
  return {
    contacts: contacts.sort((left, right) => left.order - right.order),
    messages: messages.sort((left, right) => Date.parse(left.createdAt) - Date.parse(right.createdAt))
  };
}

export async function saveContact(contact: Contact): Promise<void> {
  const db = await openDatabase();
  const transaction = db.transaction('contacts', 'readwrite');
  transaction.objectStore('contacts').put(contact);
  await transactionDone(transaction);
}

export async function saveMessage(message: Message): Promise<void> {
  const db = await openDatabase();
  const transaction = db.transaction('messages', 'readwrite');
  transaction.objectStore('messages').put(message);
  await transactionDone(transaction);
}

export async function removeMessage(id: string): Promise<void> {
  const db = await openDatabase();
  const transaction = db.transaction('messages', 'readwrite');
  transaction.objectStore('messages').delete(id);
  await transactionDone(transaction);
}

export async function replaceLocalData(backup: BackupFile): Promise<void> {
  const db = await openDatabase();
  const transaction = db.transaction(['contacts', 'messages'], 'readwrite');
  const contacts = transaction.objectStore('contacts');
  const messages = transaction.objectStore('messages');
  contacts.clear();
  messages.clear();
  for (const contact of backup.contacts) contacts.put(contact);
  for (const message of backup.messages) messages.put(message);
  await transactionDone(transaction);
}

export async function clearLocalData(): Promise<void> {
  const db = await openDatabase();
  const transaction = db.transaction(['contacts', 'messages'], 'readwrite');
  transaction.objectStore('contacts').clear();
  transaction.objectStore('messages').clear();
  await transactionDone(transaction);
}

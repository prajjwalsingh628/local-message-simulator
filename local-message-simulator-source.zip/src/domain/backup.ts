import { CONTACT_IDS, PRIMARY_CONTACT_ID, type BackupFile, type Contact, type Message } from './types';

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isValidDate(value: unknown): value is string {
  return typeof value === 'string' && Number.isFinite(Date.parse(value));
}

export function validateBackup(value: unknown): BackupFile {
  if (!isRecord(value)
    || value.format !== 'local-message-simulator-backup'
    || value.version !== 1
    || !Array.isArray(value.contacts)
    || !Array.isArray(value.messages)) {
    throw new Error('This file is not a supported local app backup.');
  }

  const contacts: Contact[] = value.contacts.map((entry) => {
    if (!isRecord(entry)
      || typeof entry.id !== 'string'
      || !CONTACT_IDS.includes(entry.id as (typeof CONTACT_IDS)[number])
      || typeof entry.name !== 'string'
      || typeof entry.countryCode !== 'string'
      || typeof entry.phoneNumber !== 'string'
      || !isRecord(entry.avatarInfo)
      || entry.avatarInfo.kind !== 'placeholder'
      || !isValidDate(entry.createdAt)
      || !isValidDate(entry.lastModifiedAt)
      || typeof entry.order !== 'number') {
      throw new Error('A contact record in this file is incomplete.');
    }
    return entry as unknown as Contact;
  });

  const contactIds = new Set(contacts.map((contact) => contact.id));
  if (contactIds.size !== contacts.length || !contactIds.has(PRIMARY_CONTACT_ID)) {
    throw new Error('The backup must contain one primary contact and no duplicate contacts.');
  }

  const messages: Message[] = value.messages.map((entry) => {
    if (!isRecord(entry)
      || typeof entry.id !== 'string'
      || entry.contactId !== PRIMARY_CONTACT_ID
      || typeof entry.text !== 'string'
      || entry.direction !== 'outgoing'
      || !isValidDate(entry.createdAt)
      || entry.localStatus !== 'saved-locally-not-delivered'
      || typeof entry.historical !== 'boolean') {
      throw new Error('A message record in this file is incomplete or unsupported.');
    }
    return entry as unknown as Message;
  });

  const messageIds = new Set(messages.map((message) => message.id));
  if (messageIds.size !== messages.length) {
    throw new Error('The backup contains duplicate message IDs.');
  }

  return {
    format: 'local-message-simulator-backup',
    version: 1,
    exportedAt: isValidDate(value.exportedAt) ? value.exportedAt : new Date().toISOString(),
    contacts,
    messages
  };
}

export function makeBackup(contacts: Contact[], messages: Message[]): BackupFile {
  return {
    format: 'local-message-simulator-backup',
    version: 1,
    exportedAt: new Date().toISOString(),
    contacts,
    messages
  };
}

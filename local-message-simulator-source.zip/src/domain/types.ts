export const PRIMARY_CONTACT_ID = 'primary-contact';
export const CONTACT_IDS = [
  PRIMARY_CONTACT_ID,
  'contact-2',
  'contact-3',
  'contact-4',
  'contact-5',
  'contact-6',
  'contact-7'
] as const;

export type ContactId = (typeof CONTACT_IDS)[number];

export interface Contact {
  id: ContactId;
  name: string;
  countryCode: string;
  phoneNumber: string;
  avatarInfo: { kind: 'placeholder' };
  createdAt: string;
  lastModifiedAt: string;
  order: number;
  localPreview?: string;
  displayTime?: string;
}

export interface Message {
  id: string;
  contactId: ContactId;
  text: string;
  direction: 'outgoing';
  createdAt: string;
  localStatus: 'saved-locally-not-delivered';
  historical: boolean;
}

export interface BackupFile {
  format: 'local-message-simulator-backup';
  version: 1;
  exportedAt: string;
  contacts: Contact[];
  messages: Message[];
}
